local dxfont = renderCreateFont('Verdana', 8, 9)
local active = false

function main()
	if not isSampLoaded() or not isSampfuncsLoaded() then return end
    while not isSampAvailable() do wait(100) end
    sampRegisterChatCommand('objr', function()
        active = not active
    end)
    while true do
        if active then
            for k, v in ipairs(getAllObjects()) do
                local px, py, pz = getCharCoordinates(PLAYER_PED)
                if doesObjectExist(v) and isObjectOnScreen(v) then
                    local model = getObjectModel(v)
                    local ok, x, y, z = getObjectCoordinates(v)
                    if ok then
                        local dist = getDistanceBetweenCoords3d(x, y, z, px, py, pz)
                        if (dist > 1 and dist < 200) then
                            local x, y = convert3DCoordsToScreen(x, y, z)
                            local str = 'Object:' .. model .. string.format('(%.1f m)', dist)
                            local nx = renderGetFontDrawTextLength(dxfont, str) / 2
                            renderFontDrawText(dxfont, str, x - nx, y, 0xFF999966)
                        end
                    end
                end
            end
        end
        wait(0)
    end
end