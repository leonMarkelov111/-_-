local dxfont = renderCreateFont('Verdana', 8, 9)
local active = false

function main()
	if not isSampLoaded() or not isSampfuncsLoaded() then return end
    while not isSampAvailable() do wait(100) end
    sampRegisterChatCommand('carr', function()
        active = not active
    end)
    while true do
        if active then
            for k, v in ipairs(getAllVehicles()) do
                if doesVehicleExist(v) and isCarOnScreen(v) then
                    local result, model = sampGetVehicleIdByCarHandle(v)
					if result then 
						local x, y, z = getCarCoordinates(v)
						local px, py, pz = getCharCoordinates(PLAYER_PED)
						local dist = getDistanceBetweenCoords3d(x, y, z, px, py, pz)
						if (dist > 1 and dist < 200) then
							local x, y = convert3DCoordsToScreen(x, y, z)
							local str = 'Car: ' .. model .. string.format('(%.1f m)', dist)
							local nx = renderGetFontDrawTextLength(dxfont, str) / 2
							renderFontDrawText(dxfont, str, x - nx, y, 0xFFCCCCCC)
						end
					end
                end
            end
        end
        wait(0)
    end
end