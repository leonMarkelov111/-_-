local q = require 'lib.samp.events'

_colors = {}
_recolor = {}
for line in io.lines('moonloader\\recolorer.txt') do 
	local color, recolor = string.match(line, '(%S+):(%S+)')
	table.insert(_colors, tonumber(color)); table.insert(_recolor, tonumber(recolor))
end

function main()
	repeat wait(0) until isSampAvailable()
	sampRegisterChatCommand('color',
		function(i)
			dbug = not dbug
			sampfuncsLog('---chat---')
		end)
	wait(-1)
end

function q.onServerMessage(color, text)
	if dbug then sampfuncsLog('['..color..'] - '..text) end
	for i = 1, #_colors do
		if color == _colors[i] then return {_recolor[i], text} end
	end
end